This is a pure-Python implemntation of SNMP SMI parser. This software
is designed to accomodate multiple code generation backends in hope
that they could be useful for SNMP MIB format convertions. However,
the only code generation backend currently offered is pysnmp [1].

For full PySMI documentation please refer to http://pysmi.sf.net
or to docs directory in this distribution.

1. http://pysnmp.sf.net

