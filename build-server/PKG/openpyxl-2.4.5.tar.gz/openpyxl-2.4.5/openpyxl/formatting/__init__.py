from __future__ import absolute_import
# Copyright (c) 2010-2017 openpyxl

from .rule import Rule
