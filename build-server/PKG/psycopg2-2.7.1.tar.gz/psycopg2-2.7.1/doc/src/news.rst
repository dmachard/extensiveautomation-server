Release notes
=============

.. include:: ../../NEWS
