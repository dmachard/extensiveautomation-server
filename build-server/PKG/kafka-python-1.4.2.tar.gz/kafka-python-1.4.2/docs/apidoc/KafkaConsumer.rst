KafkaConsumer
=============

.. autoclass:: kafka.KafkaConsumer
    :members:
