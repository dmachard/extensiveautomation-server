==========
Change log
==========

.. literalinclude:: ../ChangeLog

.. Please see the `ChangeLog` file located in the root of the pymssql source
   code tree.
