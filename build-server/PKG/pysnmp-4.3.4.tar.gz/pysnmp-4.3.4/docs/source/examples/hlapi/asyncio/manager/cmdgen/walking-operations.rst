.. toctree::
   :maxdepth: 2

Walking operations
------------------

.. include:: /../../examples/hlapi/asyncio/manager/cmdgen/getbulk-to-eom.py
   :start-after: """
   :end-before: """#

.. literalinclude:: /../../examples/hlapi/asyncio/manager/cmdgen/getbulk-to-eom.py
   :start-after: """#
   :language: python

:download:`Download</../../examples/hlapi/asyncio/manager/cmdgen/getbulk-to-eom.py>` script.

See also: :doc:`library reference </docs/api-reference>`.
