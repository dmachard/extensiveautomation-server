.. toctree::
   :maxdepth: 2

Advanced Notification Originator
--------------------------------

.. include:: /../../examples/hlapi/asyncore/sync/agent/ntforg/custom-contextname.py
   :start-after: """
   :end-before: """#

.. literalinclude:: /../../examples/hlapi/asyncore/sync/agent/ntforg/custom-contextname.py
   :start-after: """#
   :language: python

:download:`Download</../../examples/hlapi/asyncore/sync/agent/ntforg/custom-contextname.py>` script.


.. include:: /../../examples/hlapi/asyncore/sync/agent/ntforg/custom-contextengineid.py
   :start-after: """
   :end-before: """#

.. literalinclude:: /../../examples/hlapi/asyncore/sync/agent/ntforg/custom-contextengineid.py
   :start-after: """#
   :language: python

:download:`Download</../../examples/hlapi/asyncore/sync/agent/ntforg/custom-contextengineid.py>` script.

See also: :doc:`library reference </docs/api-reference>`.
