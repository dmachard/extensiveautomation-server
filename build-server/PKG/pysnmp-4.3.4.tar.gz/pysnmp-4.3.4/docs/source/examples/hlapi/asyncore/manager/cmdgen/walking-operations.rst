.. toctree::
   :maxdepth: 2

Walking operations
------------------

.. include:: /../../examples/hlapi/asyncore/manager/cmdgen/pull-whole-mib.py
   :start-after: """
   :end-before: """#

.. literalinclude:: /../../examples/hlapi/asyncore/manager/cmdgen/pull-whole-mib.py
   :start-after: """#
   :language: python

:download:`Download</../../examples/hlapi/asyncore/manager/cmdgen/pull-whole-mib.py>` script.


See also: :doc:`library reference </docs/api-reference>`.
