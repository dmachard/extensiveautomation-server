.. toctree::
   :maxdepth: 2

Table operations
----------------

.. include:: /../../examples/v3arch/asyncore/manager/cmdgen/getbulk-fetch-scalar-and-table-variables.py
   :start-after: """
   :end-before: """#

.. literalinclude:: /../../examples/v3arch/asyncore/manager/cmdgen/getbulk-fetch-scalar-and-table-variables.py
   :start-after: """#
   :language: python

:download:`Download</../../examples/v3arch/asyncore/manager/cmdgen/getbulk-fetch-scalar-and-table-variables.py>` script.

.. include:: /../../examples/v3arch/asyncore/manager/cmdgen/pull-subtree.py
   :start-after: """
   :end-before: """#

.. literalinclude:: /../../examples/v3arch/asyncore/manager/cmdgen/pull-subtree.py
   :start-after: """#
   :language: python

:download:`Download</../../examples/v3arch/asyncore/manager/cmdgen/pull-subtree.py>` script.


See also: :doc:`library reference </docs/api-reference>`.
