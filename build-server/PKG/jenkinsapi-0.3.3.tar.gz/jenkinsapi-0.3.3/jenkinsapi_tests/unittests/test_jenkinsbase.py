class TestJenkinsBaseMixin(object):

    """
    Tests which apply to all or most Jenkins objects
    """
    pass
