"How To..." examples
====================

This directory contains a set of examples or recipes for common tasks in
JenkinsAPI. 