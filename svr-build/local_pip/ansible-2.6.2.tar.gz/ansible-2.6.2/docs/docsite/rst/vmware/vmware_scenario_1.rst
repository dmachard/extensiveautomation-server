.. _vmware_scenario_1:

**********************************
Sample Scenario for Ansible VMware
**********************************

Introductory paragraph.


Scenario Requirements
=====================

Describe the requirements and assumptions for this scenario.


Example Description
===================

Description and code here.


Example Output
--------------

What the user should expect to see.


Troubleshooting
---------------

What to look for if it breaks.


Conclusion and Where To Go Next
===============================

Blah blah for more information please see blah blah...

