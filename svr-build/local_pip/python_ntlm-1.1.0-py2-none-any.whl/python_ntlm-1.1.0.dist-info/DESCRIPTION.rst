This package allows Python clients running on any operating
system to provide NTLM authentication to a supporting server.

python-ntlm is probably most useful on platforms that are not
Windows, since on Windows it is possible to take advantage of
platform-specific NTLM support.

This is also useful for passing hashes to servers requiring
ntlm authentication in instances where using windows tools is 
not desirable.

