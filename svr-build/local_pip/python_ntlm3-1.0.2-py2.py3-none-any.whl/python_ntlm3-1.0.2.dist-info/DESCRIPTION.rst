This package allows Python clients running on any operating
system to provide NTLM authentication to a supporting server.


